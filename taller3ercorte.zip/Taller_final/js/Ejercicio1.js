// EJERCICIO 1: BIBLIOTECA DIGITAL
// Conceptos: Encapsulación, Abstracción y Atributos

class Biblioteca {
  // Atributos encapsulados (privados)
  #titulo;
  #autor;
  #año;

  // Constructor usando setters (mejora: validación y control)
  constructor(titulo, autor, año) {
    this.setTitulo(titulo);
    this.setAutor(autor);
    this.setAño(año);
  }

  // ---------- Encapsulación: getters y setters ----------

  getTitulo() {
    return this.#titulo;
  }
  setTitulo(valor) {
    if (typeof valor !== "string" || valor.trim() === "") {
      throw new Error("El título no puede estar vacío.");
    }
    this.#titulo = valor.trim();
  }

  getAutor() {
    return this.#autor;
  }
  setAutor(valor) {
    if (typeof valor !== "string" || valor.trim() === "") {
      throw new Error("El autor no puede estar vacío.");
    }
    this.#autor = valor.trim();
  }

  getAño() {
    return this.#año;
  }
  setAño(valor) {
    const n = Number(valor);
    if (!Number.isFinite(n) || n <= 0) {
      throw new Error("El año debe ser un número válido.");
    }
    this.#año = n;
  }

  // ---------- Abstracción: métodos que ocultan la implementación interna ----------

  obtenerDescripcion() {
    // No revelamos cómo se guardan los datos internamente
    return `Libro: ${this.#titulo} de ${this.#autor} (${this.#año})`;
  }

  actualizarTitulo(nuevoTitulo) {
    if (nuevoTitulo && nuevoTitulo.trim() !== "") {
      this.#titulo = nuevoTitulo.trim();
      return `Título actualizado: ${this.#titulo}`;
    } else {
      return `El título no puede estar vacío`;
    }
  }
}

// =========================
// Función del ejercicio
// =========================

function ejercicio1() {
  console.log("=== EJERCICIO 1: BIBLIOTECA DIGITAL ===");
  
  // Instanciar un objeto de la clase Biblioteca
  const libro1 = new Biblioteca("1984", "George Orwell", 1949);
  
  // Obtener descripción inicial
  console.log(libro1.obtenerDescripcion());
  
  // Actualizar el título
  const resultado = libro1.actualizarTitulo("Rebelión en la granja");
  console.log(resultado);
  
  // Mostrar nueva descripción
  console.log(libro1.obtenerDescripcion());
  
  // Mostrar con alert (se mantiene igual)
  alert(`${libro1.obtenerDescripcion()}\n${resultado}`);
}