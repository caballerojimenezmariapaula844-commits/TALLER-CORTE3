// EJERCICIO 2: MASCOTA VIRTUAL
// Conceptos: Encapsulación, Abstracción y Atributos

class MascotaVirtual {
  // Atributos privados
  #nombre;
  #tipo;
  #energia;

  constructor(nombre, tipo, energiaInicial = 50) {
    this.setNombre(nombre);
    this.setTipo(tipo);
    this.setEnergia(energiaInicial);
  }

  // ---------------------------
  // Encapsulación: getters/setters
  // ---------------------------

  getNombre() {
    return this.#nombre;
  }
  setNombre(valor) {
    if (!valor || typeof valor !== "string") {
      throw new Error("El nombre debe ser un texto válido.");
    }
    this.#nombre = valor.trim();
  }

  getTipo() {
    return this.#tipo;
  }
  setTipo(valor) {
    if (!valor || typeof valor !== "string") {
      throw new Error("El tipo debe ser un texto válido.");
    }
    this.#tipo = valor.trim();
  }

  getEnergia() {
    return this.#energia;
  }
  setEnergia(valor) {
    let n = Number(valor);
    if (!Number.isFinite(n)) n = 0;

    // límites de energía
    if (n < 0) n = 0;
    if (n > 100) n = 100;

    this.#energia = n;
  }

  // ---------------------------
  // Abstracción: métodos públicos
  // ---------------------------

  // Método para alimentar (aumenta energía)
  alimentar() {
    if (this.#energia < 100) {
      this.setEnergia(this.#energia + 20);
      return `${this.#nombre} ha sido alimentado. Energía: ${this.#energia}`;
    } else {
      return `${this.#nombre} está lleno. Energía máxima alcanzada.`;
    }
  }

  // Método para jugar (disminuye energía)
  jugar() {
    if (this.#energia > 0) {
      this.setEnergia(this.#energia - 15);
      return `${this.#nombre} ha jugado. Energía: ${this.#energia}`;
    } else {
      return `${this.#nombre} está muy cansado para jugar.`;
    }
  }

  // Método para obtener el estado actual
  obtenerEstado() {
    let estado = "";
    
    if (this.#energia > 70) {
      estado = "muy enérgico";
    } else if (this.#energia > 40) {
      estado = "normal";
    } else if (this.#energia > 15) {
      estado = "cansado";
    } else {
      estado = "agotado";
    }

    return `${this.#nombre} (${this.#tipo}) - Energía: ${this.#energia}/100 - Estado: ${estado}`;
  }
}

// =========================
// Función del ejercicio
// =========================

function ejercicio2() {
  console.log("=== EJERCICIO 2: MASCOTA VIRTUAL ===");
  
  // Crear una mascota tipo gato
  const miGato = new MascotaVirtual("Michi", "gato", 60);
  
  console.log(miGato.obtenerEstado());
  
  console.log(miGato.jugar());
  console.log(miGato.obtenerEstado());
  
  console.log(miGato.jugar());
  console.log(miGato.obtenerEstado());
  
  console.log(miGato.alimentar());
  console.log(miGato.obtenerEstado());
  
  console.log(miGato.alimentar());
  console.log(miGato.obtenerEstado());
  
  const miPerro = new MascotaVirtual("Firulais", "perro", 30);
  console.log("\n--- Segunda mascota ---");
  console.log(miPerro.obtenerEstado());
  console.log(miPerro.alimentar());
  console.log(miPerro.obtenerEstado());
  
  alert(`Mascota 1: ${miGato.obtenerEstado()}\nMascota 2: ${miPerro.obtenerEstado()}`);
}