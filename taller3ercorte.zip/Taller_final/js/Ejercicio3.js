// EJERCICIO 3: POLIMORFISMO CON ANIMALES
// Conceptos: Herencia, Polimorfismo
// (Agregado: Encapsulación, Abstracción y Atributos)

// Clase padre: Animal (abstracción mediante estructura base)
class Animal {
  // Atributo privado (encapsulación)
  #nombre;
  #especie;

  constructor(nombre, especie = "Animal") {
    this.setNombre(nombre);
    this.#especie = especie; // atributo adicional
  }

  // ---------- Encapsulación: getters / setters ----------
  getNombre() {
    return this.#nombre;
  }

  setNombre(valor) {
    if (!valor || typeof valor !== "string") {
      throw new Error("El nombre debe ser texto válido.");
    }
    this.#nombre = valor.trim();
  }

  getEspecie() {
    return this.#especie;
  }

  // ---------- Abstracción ----------
  // Método genérico (se sobreescribe en subclases)
  hablar() {
    return `${this.#nombre} hace un sonido.`;
  }
}

// Clase hija: Perro
class Perro extends Animal {
  constructor(nombre) {
    super(nombre, "Perro");
  }

  // Sobreescritura del método hablar (polimorfismo)
  hablar() {
    return `${this.getNombre()} dice: Guau`;
  }
}

// Clase hija: Gato
class Gato extends Animal {
  constructor(nombre) {
    super(nombre, "Gato");
  }

  hablar() {
    return `${this.getNombre()} dice: Miau`;
  }
}

// Clase adicional: Criatura misteriosa
class CriaturaMisteriosa extends Animal {
  constructor(nombre) {
    super(nombre, "Criatura Misteriosa");
  }

  hablar() {
    return `${this.getNombre()} hace ruidos extraños...`;
  }
}

function ejercicio3() {
  console.log("=== EJERCICIO 3: POLIMORFISMO CON ANIMALES ===");
  
  const animales = [
    new Perro("Firulais"),
    new Gato("Michi"),
    new CriaturaMisteriosa("Criatura misteriosa")
  ];

  console.log("--- Todos los animales hablan ---");
  animales.forEach(animal => {
    console.log(animal.hablar());
  });

  console.log("\n--- Ejemplo individual ---");
  const miPerro = new Perro("Rex");
  const miGato = new Gato("Garfield");

  console.log(miPerro.hablar());
  console.log(miGato.hablar());

  let mensaje = "Polimorfismo en acción:\n\n";
  animales.forEach(animal => {
    mensaje += animal.hablar() + "\n";
  });

  alert(mensaje);
}