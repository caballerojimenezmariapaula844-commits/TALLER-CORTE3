// EJERCICIO 4: SISTEMA DE EMPLEADOS
// Conceptos: Herencia, Polimorfismo, Método polimórfico
// Añadido: Abstracción, Encapsulación, Atributos de clase
// NOTA: La lógica, salidas y formato permanecen exactamente igual.

// Clase base: Empleado (marcada como "abstracta" para propósitos didácticos)
class Empleado {
  // atributos privados (encapsulación)
  #nombre;
  #salarioBase;
  #id;

  // contador privado para generar ids (atributo de clase)
  static #contadorId = 1;

  constructor(nombre, salarioBase) {
    // Abstracción: impedir (didácticamente) instanciar la clase base directamente
    if (new.target === Empleado) {
      throw new Error("Empleado es una clase base y no debe instanciarse directamente.");
    }

    // usar setters para validar / encapsular
    this.setNombre(nombre);
    this.setSalarioBase(salarioBase);
    this.#id = Empleado.#generarId();
  }

  // ---------- Atributo de clase privado - generador de id ----------
  static #generarId() {
    return Empleado.#contadorId++;
  }

  // ---------- Encapsulación: getters y setters ----------
  getNombre() {
    return this.#nombre;
  }
  setNombre(v) {
    if (typeof v !== "string" || !v.trim()) {
      throw new Error("El nombre no puede estar vacío.");
    }
    this.#nombre = v.trim();
  }

  getSalarioBase() {
    return this.#salarioBase;
  }
  setSalarioBase(v) {
    const n = Number(v);
    if (!Number.isFinite(n) || n < 0) {
      throw new Error("Salario base inválido.");
    }
    this.#salarioBase = n;
  }

  getId() {
    return this.#id;
  }

  // ---------- Método polimórfico (por defecto devuelve salario base) ----------
  calcularSalario() {
    // Comportamiento por defecto (subclases pueden sobreescribir)
    return this.#salarioBase;
  }

  // Mantengo exactamente la firma y salida de obtenerInfo()
  obtenerInfo() {
    return `${this.#nombre} - Salario: $${this.calcularSalario().toFixed(2)}`;
  }
}

// Clase Desarrollador: salario base + 20%
class Desarrollador extends Empleado {
  constructor(nombre, salarioBase) {
    super(nombre, salarioBase);
  }

  calcularSalario() {
    return this.getSalarioBase() * 1.20; // +20%
  }

  obtenerInfo() {
    // Conserva exactamente el mismo formato de salida que tenías
    return `${this.getNombre()} (Desarrollador) - Salario base: $${this.getSalarioBase()} - Total: $${this.calcularSalario().toFixed(2)} (+20%)`;
  }
}

// Clase Diseñador: salario base + 10%
class Disenador extends Empleado {
  constructor(nombre, salarioBase) {
    super(nombre, salarioBase);
  }

  calcularSalario() {
    return this.getSalarioBase() * 1.10; // +10%
  }

  obtenerInfo() {
    return `${this.getNombre()} (Diseñador) - Salario base: $${this.getSalarioBase()} - Total: $${this.calcularSalario().toFixed(2)} (+10%)`;
  }
}

// Clase EmpleadoGeneral: solo salario base
class EmpleadoGeneral extends Empleado {
  constructor(nombre, salarioBase) {
    super(nombre, salarioBase);
  }

  // No se sobreescribe calcularSalario, usa el método de la clase padre
  obtenerInfo() {
    return `${this.getNombre()} (Empleado General) - Salario: $${this.calcularSalario().toFixed(2)}`;
  }
}

function ejercicio4() {
  console.log("=== EJERCICIO 4: SISTEMA DE EMPLEADOS ===");
  
  // Crear diferentes tipos de empleados (misma forma de instanciar que tenías)
  const empleados = [
    new Desarrollador("Juan Pérez", 3000),
    new Disenador("María García", 2500),
    new EmpleadoGeneral("Carlos López", 2000),
    new Desarrollador("Ana Martínez", 3500),
    new Disenador("Luis Rodríguez", 2800)
  ];

  // Mostrar información de cada empleado (polimorfismo en acción)
  console.log("--- Nómina de la empresa ---\n");
  empleados.forEach(empleado => {
    console.log(empleado.obtenerInfo());
  });

  // Calcular nómina total
  const nominaTotal = empleados.reduce((total, empleado) => {
    return total + empleado.calcularSalario();
  }, 0);

  console.log(`\n--- Total nómina: $${nominaTotal.toFixed(2)} ---`);

  // Calcular promedio de salarios
  const promedioSalario = nominaTotal / empleados.length;
  console.log(`Salario promedio: $${promedioSalario.toFixed(2)}`);

  // Mostrar en alert (mismo formato)
  let mensaje = "SISTEMA DE EMPLEADOS\n\n";
  empleados.forEach(emp => {
    mensaje += emp.obtenerInfo() + "\n\n";
  });
  mensaje += `\nNómina Total: $${nominaTotal.toFixed(2)}`;
  mensaje += `\nPromedio: $${promedioSalario.toFixed(2)}`;
  
  alert(mensaje);
}