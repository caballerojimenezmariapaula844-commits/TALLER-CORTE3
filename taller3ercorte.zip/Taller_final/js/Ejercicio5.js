// Ejercicio5.js - SISTEMA DE VEHÍCULOS (mejorado)

// Clase base abstracta
class Vehiculo {
  #marca;
  #modelo;
  #anio;
  #estado; // apagado/encendido

  constructor(marca, modelo, anio) {
    if (new.target === Vehiculo) {
      throw new Error("Vehiculo es abstracto; instanciar una subclase concreta.");
    }
    this.marca = marca;
    this.modelo = modelo;
    this.anio = anio;
    this.#estado = "apagado";
  }

  get marca() { return this.#marca; }
  set marca(v) {
    if (typeof v !== "string" || !v.trim()) throw new Error("Marca inválida");
    this.#marca = v.trim();
  }

  get modelo() { return this.#modelo; }
  set modelo(v) {
    if (typeof v !== "string" || !v.trim()) throw new Error("Modelo inválido");
    this.#modelo = v.trim();
  }

  get anio() { return this.#anio; }
  set anio(v) {
    const n = Number(v);
    if (!Number.isFinite(n) || n < 1900) throw new Error("Año inválido (>=1900).");
    this.#anio = n;
  }

  arrancar() {
    if (this.#estado === "encendido") return `${this.marca} ${this.modelo} ya está encendido.`;
    this.#estado = "encendido";
    return `${this.marca} ${this.modelo} arrancó.`;
  }

  detener() {
    if (this.#estado === "apagado") return `${this.marca} ${this.modelo} ya está apagado.`;
    this.#estado = "apagado";
    return `${this.marca} ${this.modelo} se detuvo.`;
  }

  obtenerTipo() {
    return "vehículo genérico";
  }

  obtenerInfo() {
    return `${this.obtenerTipo()} - ${this.marca} ${this.modelo} (${this.anio})`;
  }
}

// Moto
class Moto extends Vehiculo {
  #cilindrada;
  constructor(marca, modelo, anio, cilindrada = 125) {
    super(marca, modelo, anio);
    this.cilindrada = cilindrada;
  }

  get cilindrada() { return this.#cilindrada; }
  set cilindrada(v) {
    const n = Number(v);
    if (!Number.isFinite(n) || n <= 0) throw new Error("Cilindrada inválida.");
    this.#cilindrada = n;
  }

  obtenerTipo() { return "Moto"; }

  obtenerInfo() {
    return `${super.obtenerInfo()}, Cilindrada: ${this.#cilindrada}cc`;
  }
}

// Carro
class Carro extends Vehiculo {
  #numPuertas;
  constructor(marca, modelo, anio, numPuertas = 4) {
    super(marca, modelo, anio);
    this.numPuertas = numPuertas;
  }

  get numPuertas() { return this.#numPuertas; }
  set numPuertas(v) {
    const n = Number(v);
    if (!Number.isInteger(n) || n <= 0) throw new Error("Número de puertas inválido.");
    this.#numPuertas = n;
  }

  obtenerTipo() { return "Carro"; }

  obtenerInfo() {
    return `${super.obtenerInfo()}, Puertas: ${this.#numPuertas}`;
  }
}

// Camion
class Camion extends Vehiculo {
  #capacidadCarga;
  constructor(marca, modelo, anio, capacidadCarga = 1) {
    super(marca, modelo, anio);
    this.capacidadCarga = capacidadCarga;
  }

  get capacidadCarga() { return this.#capacidadCarga; }
  set capacidadCarga(v) {
    const n = Number(v);
    if (!Number.isFinite(n) || n <= 0) throw new Error("Capacidad de carga inválida.");
    this.#capacidadCarga = n;
  }

  obtenerTipo() { return "Camión"; }

  obtenerInfo() {
    return `${super.obtenerInfo()}, Capacidad: ${this.#capacidadCarga} t`;
  }
}

// Función de prueba pública
function ejercicio5() {
  console.log("=== EJERCICIO 5 (mejorado) ===");
  const inventario = [
    new Moto("Yamaha", "R15", 2023, 150),
    new Carro("Toyota", "Corolla", 2024, 4),
    new Camion("Volvo", "FH16", 2023, 25)
  ];

  inventario.forEach(v => {
    console.log(v.obtenerInfo());
    console.log(v.arrancar());
    console.log(v.detener());
  });

  const resumen = {
    total: inventario.length,
    detalles: inventario.map(v => v.obtenerInfo())
  };

  return resumen;
}